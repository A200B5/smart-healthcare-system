// Admin-specific page components

interface AdminPageProps {
  navigate?: (page: string) => void;
}

// Admin Doctors Management
export const AdminDoctors = () => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <h1 className="text-[36px] mb-2" style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
      Manage Doctors
    </h1>
    <p className="text-base mb-9" style={{ color: 'var(--text-secondary)' }}>View and manage all registered doctors</p>

    <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
         style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
         onMouseEnter={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-md)';
         }}
         onMouseLeave={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
         }}>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
        <div className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>All Doctors (8)</div>
        <button className="px-7 py-3 rounded-full text-[15px] font-semibold transition-all duration-300 border-2 text-white"
                style={{ background: 'var(--primary-teal)', borderColor: 'var(--primary-teal)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal-dark)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}>
          + Add Doctor
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[600px]" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Doctor</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Specialty</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Experience</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Fee</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Status</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {[
              { name: 'Dr. Sarah Johnson', specialty: 'Cardiology', exp: '15y', fee: '$150', status: 'available', icon: '👩‍⚕️' },
              { name: 'Dr. Ahmed Hassan', specialty: 'Neurology', exp: '12y', fee: '$180', status: 'available', icon: '👨‍⚕️' },
              { name: 'Dr. Mona Khalil', specialty: 'Pediatrics', exp: '10y', fee: '$120', status: 'available', icon: '👩‍⚕️' },
              { name: 'Dr. Omar Farouk', specialty: 'Orthopedics', exp: '18y', fee: '$200', status: 'busy', icon: '👨‍⚕️' },
              { name: 'Dr. Layla Mansour', specialty: 'Dermatology', exp: '8y', fee: '$130', status: 'available', icon: '👩‍⚕️' }
            ].map((doctor, i) => (
              <tr key={i} className="transition-all duration-300"
                  style={{ background: 'transparent' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'var(--bg-secondary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  <div className="flex items-center gap-[10px] font-semibold">{doctor.icon} {doctor.name}</div>
                </td>
                <td className="px-4 py-4 text-[15px] font-semibold border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--primary-teal)' }}>
                  {doctor.specialty}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {doctor.exp}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {doctor.fee}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="px-[14px] py-1 rounded-full text-xs font-semibold capitalize"
                        style={{
                          background: doctor.status === 'available' ? 'var(--available-bg)' : 'var(--busy-bg)',
                          color: doctor.status === 'available' ? 'var(--available)' : 'var(--busy)'
                        }}>
                    {doctor.status}
                  </span>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="px-5 py-2 rounded-full text-[13px] font-bold transition-all duration-300 border-none text-white"
                          style={{ background: 'var(--primary-teal)' }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.transform = 'translateY(-1px)';
                            e.currentTarget.style.opacity = '0.9';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.transform = 'translateY(0)';
                            e.currentTarget.style.opacity = '1';
                          }}>
                    Manage
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

// Admin Users Management
export const AdminUsers = () => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <h1 className="text-[36px] mb-2" style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
      Manage Users
    </h1>
    <p className="text-base mb-9" style={{ color: 'var(--text-secondary)' }}>View and manage all platform users</p>

    <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
         style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
         onMouseEnter={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-md)';
         }}
         onMouseLeave={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
         }}>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
        <div className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>All Users (50,247)</div>
        <div className="flex gap-[10px]">
          {['All', 'Patients', 'Doctors', 'Admins'].map((tab, i) => (
            <button key={i}
                    className="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 border-2"
                    style={{
                      background: i === 0 ? 'var(--primary-teal)' : 'var(--bg-card)',
                      color: i === 0 ? 'white' : 'var(--text-secondary)',
                      borderColor: i === 0 ? 'var(--primary-teal)' : 'var(--border-color)',
                      margin: 0
                    }}
                    onMouseEnter={(e) => {
                      if (i !== 0) {
                        e.currentTarget.style.borderColor = 'var(--primary-teal)';
                        e.currentTarget.style.color = 'var(--primary-teal)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (i !== 0) {
                        e.currentTarget.style.borderColor = 'var(--border-color)';
                        e.currentTarget.style.color = 'var(--text-secondary)';
                      }
                    }}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[600px]" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>User</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Email</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Role</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Joined</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Status</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {[
              { name: 'John Patient', email: 'john@email.com', role: 'Patient', joined: '2025-01-15', icon: '👤', roleColor: 'confirmed' },
              { name: 'Sara Ali', email: 'sara@email.com', role: 'Patient', joined: '2025-02-10', icon: '👤', roleColor: 'confirmed' },
              { name: 'Dr. Sarah Johnson', email: 'sarah@medicare.com', role: 'Doctor', joined: '2024-11-20', icon: '👨‍⚕️', roleColor: 'completed' },
              { name: 'Ahmed Sabry', email: 'ahmedsabry8818@gmail.com', role: 'Admin', joined: '2024-10-01', icon: '🔑', roleColor: 'pending' }
            ].map((user, i) => (
              <tr key={i} className="transition-all duration-300"
                  style={{ background: 'transparent' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'var(--bg-secondary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  <div className="flex items-center gap-[10px] font-semibold">{user.icon} {user.name}</div>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {user.email}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="px-[14px] py-1 rounded-full text-xs font-semibold"
                        style={{
                          background: user.roleColor === 'confirmed' ? 'var(--confirmed-bg)' :
                                     user.roleColor === 'completed' ? 'var(--completed-bg)' : 'var(--pending-bg)',
                          color: user.roleColor === 'confirmed' ? 'var(--confirmed)' :
                                 user.roleColor === 'completed' ? 'var(--completed)' : 'var(--pending)'
                        }}>
                    {user.role}
                  </span>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {user.joined}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="px-[14px] py-1 rounded-full text-xs font-semibold"
                        style={{ background: 'var(--available-bg)', color: 'var(--available)' }}>
                    Active
                  </span>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="px-5 py-2 rounded-full text-[13px] font-bold transition-all duration-300 border-none text-white"
                          style={{ background: 'var(--primary-teal)' }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.transform = 'translateY(-1px)';
                            e.currentTarget.style.opacity = '0.9';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.transform = 'translateY(0)';
                            e.currentTarget.style.opacity = '1';
                          }}>
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

// Admin Appointments Management
export const AdminAppointments = () => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <h1 className="text-[36px] mb-2" style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
      All Appointments
    </h1>
    <p className="text-base mb-9" style={{ color: 'var(--text-secondary)' }}>Monitor and manage all appointments across the platform</p>

    <div className="flex gap-[10px] mb-8 flex-wrap">
      {['All (4)', 'Pending (1)', 'Confirmed (1)', 'Completed (1)', 'Rejected (1)'].map((tab, i) => (
        <button key={i}
                className="px-6 py-[10px] rounded-full text-sm font-semibold transition-all duration-300 border-2"
                style={{
                  background: i === 0 ? 'var(--primary-teal)' : 'var(--bg-card)',
                  color: i === 0 ? 'white' : 'var(--text-secondary)',
                  borderColor: i === 0 ? 'var(--primary-teal)' : 'var(--border-color)'
                }}
                onMouseEnter={(e) => {
                  if (i !== 0) {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.color = 'var(--primary-teal)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (i !== 0) {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.color = 'var(--text-secondary)';
                  }
                }}>
          {tab}
        </button>
      ))}
    </div>

    <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
         style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
         onMouseEnter={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-md)';
         }}
         onMouseLeave={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
         }}>
      <div className="text-xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Appointments List</div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[600px]" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Patient</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Doctor</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Specialty</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Date</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Time</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Fee</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {[
              { patient: 'John Patient', doctor: 'Dr. Sarah Johnson', specialty: 'Cardiology', date: '2025-04-15', time: '10:00 AM', fee: '$150', status: 'confirmed' },
              { patient: 'John Patient', doctor: 'Dr. Ahmed Hassan', specialty: 'Neurology', date: '2025-04-20', time: '2:00 PM', fee: '$180', status: 'pending' },
              { patient: 'Sara Ali', doctor: 'Dr. Mona Khalil', specialty: 'Pediatrics', date: '2025-04-18', time: '11:00 AM', fee: '$120', status: 'completed' },
              { patient: 'Mohamed Kareem', doctor: 'Dr. Layla Mansour', specialty: 'Dermatology', date: '2025-04-22', time: '3:00 PM', fee: '$130', status: 'rejected' }
            ].map((appt, i) => (
              <tr key={i} className="transition-all duration-300"
                  style={{ background: 'transparent' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'var(--bg-secondary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  <div className="flex items-center gap-[10px] font-semibold">👤 {appt.patient}</div>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {appt.doctor}
                </td>
                <td className="px-4 py-4 text-[15px] font-semibold border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--primary-teal)' }}>
                  {appt.specialty}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {appt.date}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {appt.time}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {appt.fee}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="px-[14px] py-1 rounded-full text-xs font-semibold capitalize"
                        style={{
                          background: appt.status === 'confirmed' ? 'var(--confirmed-bg)' :
                                     appt.status === 'pending' ? 'var(--pending-bg)' :
                                     appt.status === 'completed' ? 'var(--completed-bg)' : 'var(--rejected-bg)',
                          color: appt.status === 'confirmed' ? 'var(--confirmed)' :
                                 appt.status === 'pending' ? 'var(--pending)' :
                                 appt.status === 'completed' ? 'var(--completed)' : 'var(--rejected)'
                        }}>
                    {appt.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);
