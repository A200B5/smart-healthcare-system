// Additional page components for MediCare Pro

interface PageProps {
  navigate?: (page: string) => void;
  currentUser?: any;
}

// Patient Home Dashboard
export const PatientHome = ({ navigate, currentUser }: PageProps) => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <div className="rounded-[20px] px-10 py-8 mb-8 text-white flex items-center justify-between flex-wrap gap-4"
         style={{ background: 'var(--hero-gradient)' }}>
      <div>
        <h2 className="text-[28px] mb-1.5" style={{ fontFamily: "'Playfair Display', serif" }}>
          Welcome back, {currentUser?.name}! 👋
        </h2>
        <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '15px' }}>Manage your health and book appointments easily</p>
      </div>
      <div className="text-[64px]">🧑</div>
    </div>

    <div className="grid grid-cols-4 gap-6 mb-9">
      {[
        { icon: '📅', number: '3', label: 'Upcoming Appointments', color: 'teal' },
        { icon: '✅', number: '12', label: 'Completed Visits', color: 'green' },
        { icon: '👨‍⚕️', number: '5', label: 'Favorite Doctors', color: 'gold' },
        { icon: '💊', number: '8', label: 'Active Prescriptions', color: 'default' }
      ].map((stat, i) => (
        <div key={i}
             className="rounded-2xl px-7 py-7 border transition-all duration-300 cursor-default"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.transform = 'translateY(-4px)';
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.transform = 'translateY(0)';
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
             }}>
          <div className="text-4xl mb-4">{stat.icon}</div>
          <div className="text-[40px] font-extrabold mb-1"
               style={{
                 color: stat.color === 'teal' ? 'var(--primary-teal)' :
                        stat.color === 'gold' ? 'var(--accent-gold)' :
                        stat.color === 'green' ? 'var(--confirmed)' : 'var(--text-primary)'
               }}>
            {stat.number}
          </div>
          <div className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
        </div>
      ))}
    </div>

    <div className="mb-8">
      <h2 className="text-2xl font-bold mb-8" style={{ color: 'var(--text-primary)' }}>Quick Actions</h2>
    </div>

    <div className="grid grid-cols-3 gap-6">
      {[
        { icon: '🔍', title: 'Find a Doctor', desc: 'Browse our network of verified specialists', action: () => navigate('patient-doctors') },
        { icon: '📋', title: 'My Appointments', desc: 'View and manage your scheduled visits', action: () => navigate('patient-appointments') },
        { icon: '📊', title: 'Health Records', desc: 'Track your medical history', action: () => {} }
      ].map((card, i) => (
        <div key={i}
             onClick={card.action}
             className="rounded-2xl px-7 py-10 border text-center cursor-pointer transition-all duration-300"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.transform = 'translateY(-4px)';
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
               e.currentTarget.style.borderColor = 'var(--primary-teal)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.transform = 'translateY(0)';
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
               e.currentTarget.style.borderColor = 'var(--border-color)';
             }}>
          <div className="text-6xl mb-4">{card.icon}</div>
          <h3 className="text-xl mb-2" style={{ color: 'var(--text-primary)' }}>{card.title}</h3>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{card.desc}</p>
        </div>
      ))}
    </div>
  </div>
);

// Patient Find Doctors Page
export const PatientDoctors = ({ navigate }: PageProps) => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <h1 className="text-[36px] mb-2" style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
      Find Your Doctor
    </h1>
    <p className="text-base mb-9" style={{ color: 'var(--text-secondary)' }}>Browse our network of 8 verified specialists</p>

    <div className="rounded-2xl px-8 py-8 flex gap-6 items-end flex-wrap mb-8 border"
         style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-sm)', borderColor: 'var(--border-color)' }}>
      <div className="flex-1 min-w-[200px]">
        <label className="block text-xs font-semibold mb-2 uppercase tracking-wider" style={{ color: 'var(--text-secondary)' }}>Search</label>
        <input type="text" placeholder="Search by name or specialty..."
               className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
               style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
               onFocus={(e) => {
                 e.currentTarget.style.borderColor = 'var(--primary-teal)';
               }}
               onBlur={(e) => {
                 e.currentTarget.style.borderColor = 'var(--border-color)';
               }} />
      </div>
      <div className="flex-1 min-w-[200px]">
        <label className="block text-xs font-semibold mb-2 uppercase tracking-wider" style={{ color: 'var(--text-secondary)' }}>Specialty</label>
        <select className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = 'var(--primary-teal)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = 'var(--border-color)';
                }}>
          <option>All</option>
          <option>Cardiology</option>
          <option>Neurology</option>
          <option>Pediatrics</option>
          <option>Orthopedics</option>
          <option>Dermatology</option>
        </select>
      </div>
      <div className="flex-1 min-w-[200px]">
        <label className="block text-xs font-semibold mb-2 uppercase tracking-wider" style={{ color: 'var(--text-secondary)' }}>Sort By</label>
        <select className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = 'var(--primary-teal)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = 'var(--border-color)';
                }}>
          <option>Top Rated</option>
          <option>Most Experience</option>
          <option>Lowest Price</option>
        </select>
      </div>
      <div className="flex items-center gap-2 px-0 py-[14px] text-[15px]" style={{ color: 'var(--text-secondary)' }}>
        <input type="checkbox" id="available" className="w-4 h-4" />
        <label htmlFor="available" className="cursor-pointer">Available Only</label>
      </div>
    </div>

    <p className="text-[15px] mb-6" style={{ color: 'var(--text-secondary)' }}>
      Showing <strong style={{ color: 'var(--primary-teal)' }}>6</strong> doctors
    </p>

    <div className="grid grid-cols-3 gap-6">
      {[
        { name: 'Dr. Sarah Johnson', specialty: 'Cardiology', location: 'Cairo Medical Center', rating: '4.9', reviews: '238', exp: '15y', fee: '$150', status: 'available' },
        { name: 'Dr. Ahmed Hassan', specialty: 'Neurology', location: 'Nile Health Clinic', rating: '4.8', reviews: '192', exp: '12y', fee: '$180', status: 'available' },
        { name: 'Dr. Mona Khalil', specialty: 'Pediatrics', location: "Children's Hospital", rating: '4.9', reviews: '305', exp: '10y', fee: '$120', status: 'available' },
        { name: 'Dr. Omar Farouk', specialty: 'Orthopedics', location: 'Sports Medicine Center', rating: '4.7', reviews: '156', exp: '18y', fee: '$200', status: 'busy' },
        { name: 'Dr. Layla Mansour', specialty: 'Dermatology', location: 'Skin Care Clinic', rating: '4.8', reviews: '274', exp: '8y', fee: '$130', status: 'available' },
        { name: 'Dr. Karim Nabil', specialty: 'Ophthalmology', location: 'Eye Care Center', rating: '4.6', reviews: '143', exp: '14y', fee: '$140', status: 'available' }
      ].map((doctor, i) => (
        <div key={i}
             className="rounded-2xl px-7 py-7 border transition-all duration-300"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.transform = 'translateY(-4px)';
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
               e.currentTarget.style.borderColor = 'var(--primary-teal)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.transform = 'translateY(0)';
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
               e.currentTarget.style.borderColor = 'var(--border-color)';
             }}>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-full flex items-center justify-center text-[28px] border-2 flex-shrink-0"
                 style={{ background: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              {i % 2 === 0 ? '👩‍⚕️' : '👨‍⚕️'}
            </div>
            <div className="flex-1">
              <div className="text-[17px] font-bold" style={{ color: 'var(--text-primary)' }}>{doctor.name}</div>
              <div className="text-sm font-semibold" style={{ color: 'var(--primary-teal)' }}>{doctor.specialty}</div>
              <div className="text-[13px]" style={{ color: 'var(--text-secondary)' }}>📍 {doctor.location}</div>
            </div>
            <span className="px-[14px] py-1 rounded-full text-xs font-semibold"
                  style={{
                    background: doctor.status === 'available' ? 'var(--available-bg)' : 'var(--busy-bg)',
                    color: doctor.status === 'available' ? 'var(--available)' : 'var(--busy)'
                  }}>
              {doctor.status === 'available' ? '● Available' : '○ Busy'}
            </span>
          </div>

          <div className="flex justify-between mb-6 pt-5 border-t" style={{ borderColor: 'var(--border-color)' }}>
            <div className="text-center">
              <div className="text-lg font-bold flex items-center gap-1 justify-center" style={{ color: 'var(--text-primary)' }}>
                <span style={{ color: '#FBBF24' }}>⭐</span> {doctor.rating}
              </div>
              <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{doctor.reviews} reviews</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>{doctor.exp}</div>
              <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>Experience</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold" style={{ color: 'var(--primary-teal)' }}>{doctor.fee}</div>
              <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>per visit</div>
            </div>
          </div>

          <div className="flex gap-3">
            <button className="flex-1 px-3 py-3 rounded-full text-sm font-semibold transition-all duration-300 border-2"
                    style={{ background: 'transparent', borderColor: 'var(--primary-teal)', color: 'var(--primary-teal)' }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'var(--primary-teal)';
                      e.currentTarget.style.color = 'white';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.color = 'var(--primary-teal)';
                    }}>
              View Profile
            </button>
            {doctor.status === 'available' && (
              <button onClick={() => navigate('patient-appointments')}
                      className="flex-1 px-3 py-3 rounded-full text-sm font-semibold transition-all duration-300 border-2 text-white"
                      style={{ background: 'var(--primary-teal)', borderColor: 'var(--primary-teal)' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = 'translateY(-1px)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = 'translateY(0)';
                      }}>
                Book Now
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  </div>
);

// Patient Appointments Page
export const PatientAppointments = ({ navigate }: PageProps) => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <div className="flex justify-between items-start mb-8 flex-wrap gap-4">
      <div>
        <h1 className="text-[36px] mb-2" style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
          My Appointments
        </h1>
        <p className="text-base" style={{ color: 'var(--text-secondary)' }}>Track and manage all your medical appointments</p>
      </div>
      <button onClick={() => navigate('patient-doctors')}
              className="px-7 py-3 rounded-full text-[15px] font-semibold transition-all duration-300 border-2 text-white"
              style={{ background: 'var(--primary-teal)', borderColor: 'var(--primary-teal)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'var(--primary-teal-dark)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'var(--primary-teal)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}>
        + Book New Appointment
      </button>
    </div>

    <div className="flex gap-[10px] mb-8 flex-wrap">
      {['All (4)', 'Pending (1)', 'Confirmed (1)', 'Completed (1)', 'Rejected (1)'].map((tab, i) => (
        <button key={i}
                className="px-6 py-[10px] rounded-full text-sm font-semibold transition-all duration-300 border-2"
                style={{
                  background: i === 0 ? 'var(--primary-teal)' : 'var(--bg-card)',
                  color: i === 0 ? 'white' : 'var(--text-secondary)',
                  borderColor: i === 0 ? 'var(--primary-teal)' : 'var(--border-color)'
                }}
                onMouseEnter={(e) => {
                  if (i !== 0) {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.color = 'var(--primary-teal)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (i !== 0) {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.color = 'var(--text-secondary)';
                  }
                }}>
          {tab}
        </button>
      ))}
    </div>

    <div className="space-y-4">
      {[
        { doctor: 'Dr. Sarah Johnson', specialty: 'Cardiology', date: '2025-04-15', time: '10:00 AM', status: 'confirmed', icon: '👩‍⚕️' },
        { doctor: 'Dr. Ahmed Hassan', specialty: 'Neurology', date: '2025-04-20', time: '2:00 PM', status: 'pending', icon: '👨‍⚕️' },
        { doctor: 'Dr. Mona Khalil', specialty: 'Pediatrics', date: '2025-04-18', time: '11:00 AM', status: 'completed', icon: '👩‍⚕️' },
        { doctor: 'Dr. Layla Mansour', specialty: 'Dermatology', date: '2025-04-22', time: '3:00 PM', status: 'rejected', icon: '👩‍⚕️' }
      ].map((appt, i) => (
        <div key={i}
             className="rounded-2xl px-9 py-7 flex items-center justify-between gap-5 flex-wrap border transition-all duration-300"
             style={{
               background: 'var(--bg-card)',
               borderColor: 'var(--border-color)',
               borderLeft: `4px solid ${
                 appt.status === 'confirmed' ? 'var(--confirmed)' :
                 appt.status === 'pending' ? 'var(--pending)' :
                 appt.status === 'completed' ? 'var(--completed)' : 'var(--rejected)'
               }`
             }}
             onMouseEnter={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
               e.currentTarget.style.transform = 'translateX(4px)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.boxShadow = 'none';
               e.currentTarget.style.transform = 'translateX(0)';
             }}>
          <div className="flex items-center gap-4 flex-1 min-w-[200px]">
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl flex-shrink-0"
                 style={{ background: 'var(--bg-secondary)' }}>
              {appt.icon}
            </div>
            <div>
              <div className="text-[17px] font-bold" style={{ color: 'var(--text-primary)' }}>{appt.doctor}</div>
              <div className="text-sm font-semibold" style={{ color: 'var(--primary-teal)' }}>{appt.specialty}</div>
            </div>
          </div>

          <div className="flex gap-10 items-center flex-wrap">
            <div className="text-center">
              <div className="text-xs uppercase tracking-wider mb-1" style={{ color: 'var(--text-secondary)' }}>Date</div>
              <div className="text-[15px] font-semibold flex items-center gap-1.5" style={{ color: 'var(--text-primary)' }}>
                📅 {appt.date}
              </div>
            </div>
            <div className="text-center">
              <div className="text-xs uppercase tracking-wider mb-1" style={{ color: 'var(--text-secondary)' }}>Time</div>
              <div className="text-[15px] font-semibold flex items-center gap-1.5" style={{ color: 'var(--text-primary)' }}>
                🕐 {appt.time}
              </div>
            </div>
            <span className="px-[14px] py-1 rounded-full text-xs font-semibold capitalize"
                  style={{
                    background: appt.status === 'confirmed' ? 'var(--confirmed-bg)' :
                               appt.status === 'pending' ? 'var(--pending-bg)' :
                               appt.status === 'completed' ? 'var(--completed-bg)' : 'var(--rejected-bg)',
                    color: appt.status === 'confirmed' ? 'var(--confirmed)' :
                           appt.status === 'pending' ? 'var(--pending)' :
                           appt.status === 'completed' ? 'var(--completed)' : 'var(--rejected)'
                  }}>
              {appt.status}
            </span>
          </div>
        </div>
      ))}
    </div>
  </div>
);

// Doctor Dashboard
export const DoctorDashboard = ({ navigate, currentUser }: PageProps) => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <div className="rounded-[20px] px-10 py-8 mb-8 text-white flex items-center justify-between flex-wrap gap-4"
         style={{ background: 'var(--hero-gradient)' }}>
      <div>
        <h2 className="text-[28px] mb-1.5" style={{ fontFamily: "'Playfair Display', serif" }}>
          Welcome back, Dr. Bakr! 👨‍⚕️
        </h2>
        <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '15px' }}>You have new appointment requests waiting for your review</p>
      </div>
      <div className="text-[64px]">🩺</div>
    </div>

    <div className="grid grid-cols-4 gap-6 mb-9">
      {[
        { icon: '📋', number: '4', label: 'Total Appointments', color: 'teal' },
        { icon: '⏳', number: '1', label: 'Pending', color: 'yellow' },
        { icon: '✅', number: '1', label: 'Confirmed', color: 'green' },
        { icon: '🏁', number: '1', label: 'Completed', color: 'default' }
      ].map((stat, i) => (
        <div key={i}
             className="rounded-2xl px-7 py-7 border transition-all duration-300 cursor-default"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.transform = 'translateY(-4px)';
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.transform = 'translateY(0)';
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
             }}>
          <div className="text-4xl mb-4">{stat.icon}</div>
          <div className="text-[40px] font-extrabold mb-1"
               style={{
                 color: stat.color === 'teal' ? 'var(--primary-teal)' :
                        stat.color === 'yellow' ? 'var(--pending)' :
                        stat.color === 'green' ? 'var(--confirmed)' : 'var(--text-primary)'
               }}>
            {stat.number}
          </div>
          <div className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
        </div>
      ))}
    </div>

    <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
         style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
         onMouseEnter={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-md)';
         }}
         onMouseLeave={(e) => {
           e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
         }}>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
        <div className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Appointment Requests</div>
        <div className="flex gap-[10px]">
          {['all', 'pending', 'confirmed', 'completed', 'rejected'].map((tab, i) => (
            <button key={i}
                    className="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 border-2 capitalize"
                    style={{
                      background: i === 0 ? 'var(--primary-teal)' : 'var(--bg-card)',
                      color: i === 0 ? 'white' : 'var(--text-secondary)',
                      borderColor: i === 0 ? 'var(--primary-teal)' : 'var(--border-color)',
                      margin: 0
                    }}
                    onMouseEnter={(e) => {
                      if (i !== 0) {
                        e.currentTarget.style.borderColor = 'var(--primary-teal)';
                        e.currentTarget.style.color = 'var(--primary-teal)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (i !== 0) {
                        e.currentTarget.style.borderColor = 'var(--border-color)';
                        e.currentTarget.style.color = 'var(--text-secondary)';
                      }
                    }}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[600px]" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Patient</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Specialty</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Date</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Time</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Status</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {[
              { patient: 'John Patient', specialty: 'Cardiology', date: '2025-04-15', time: '10:00 AM', status: 'confirmed', action: 'Mark Done' },
              { patient: 'John Patient', specialty: 'Neurology', date: '2025-04-20', time: '2:00 PM', status: 'pending', action: 'Accept/Reject' },
              { patient: 'Sara Ali', specialty: 'Pediatrics', date: '2025-04-18', time: '11:00 AM', status: 'completed', action: null },
              { patient: 'Mohamed Kareem', specialty: 'Dermatology', date: '2025-04-22', time: '3:00 PM', status: 'rejected', action: null }
            ].map((appt, i) => (
              <tr key={i} className="transition-all duration-300"
                  style={{ background: 'transparent' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'var(--bg-secondary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  <div className="flex items-center gap-[10px] font-semibold">👤 {appt.patient}</div>
                </td>
                <td className="px-4 py-4 text-[15px] font-semibold border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--primary-teal)' }}>
                  {appt.specialty}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {appt.date}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  {appt.time}
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="px-[14px] py-1 rounded-full text-xs font-semibold capitalize"
                        style={{
                          background: appt.status === 'confirmed' ? 'var(--confirmed-bg)' :
                                     appt.status === 'pending' ? 'var(--pending-bg)' :
                                     appt.status === 'completed' ? 'var(--completed-bg)' : 'var(--rejected-bg)',
                          color: appt.status === 'confirmed' ? 'var(--confirmed)' :
                                 appt.status === 'pending' ? 'var(--pending)' :
                                 appt.status === 'completed' ? 'var(--completed)' : 'var(--rejected)'
                        }}>
                    {appt.status}
                  </span>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  {appt.action ? (
                    appt.status === 'confirmed' ? (
                      <button className="px-5 py-2 rounded-full text-[13px] font-bold transition-all duration-300 border-none text-white"
                              style={{ background: 'var(--primary-teal)' }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.transform = 'translateY(-1px)';
                                e.currentTarget.style.opacity = '0.9';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.transform = 'translateY(0)';
                                e.currentTarget.style.opacity = '1';
                              }}>
                        {appt.action}
                      </button>
                    ) : (
                      <div className="flex gap-2">
                        <button className="px-5 py-2 rounded-full text-[13px] font-bold transition-all duration-300 border-none text-white"
                                style={{ background: 'var(--confirmed)' }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = 'translateY(-1px)';
                                  e.currentTarget.style.opacity = '0.9';
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = 'translateY(0)';
                                  e.currentTarget.style.opacity = '1';
                                }}>
                          Accept
                        </button>
                        <button className="px-5 py-2 rounded-full text-[13px] font-bold transition-all duration-300 border-none text-white"
                                style={{ background: 'var(--rejected)' }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = 'translateY(-1px)';
                                  e.currentTarget.style.opacity = '0.9';
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = 'translateY(0)';
                                  e.currentTarget.style.opacity = '1';
                                }}>
                          Reject
                        </button>
                      </div>
                    )
                  ) : (
                    <span style={{ color: 'var(--text-secondary)' }}>—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

// Doctor Profile
export const DoctorProfile = ({ navigate, currentUser }: PageProps) => (
  <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
       style={{ background: 'var(--bg-secondary)' }}>
    <h1 className="text-[36px] mb-2" style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
      My Profile
    </h1>
    <p className="text-base mb-9" style={{ color: 'var(--text-secondary)' }}>Manage your professional information</p>

    <div className="rounded-[24px] px-11 py-12 max-w-[800px] mx-auto transition-all duration-300"
         style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-lg)' }}>
      <div className="flex items-center gap-6 mb-8">
        <div className="w-[100px] h-[100px] rounded-full flex items-center justify-center text-5xl text-white"
             style={{ background: 'var(--primary-teal)' }}>
          👨‍⚕️
        </div>
        <div>
          <h2 className="text-2xl mb-1">Dr. Ahmed Bakr</h2>
          <p className="font-semibold mb-1" style={{ color: 'var(--primary-teal)' }}>Cardiology Specialist</p>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>📍 Cairo Medical Center</p>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); alert('Profile updated! 🎉'); }}>
        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>First Name</label>
            <input type="text" defaultValue="Ahmed"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Last Name</label>
            <input type="text" defaultValue="Bakr"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Email</label>
          <input type="email" defaultValue="ahmedbakr8818@gmail.com"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Specialty</label>
          <input type="text" defaultValue="Cardiology"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Years of Experience</label>
            <input type="number" defaultValue="15"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Consultation Fee ($)</label>
            <input type="number" defaultValue="150"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
        </div>

        <button type="submit"
                className="w-full py-4 rounded-full text-base font-bold transition-all duration-300 mt-3 border-none text-white"
                style={{ background: 'var(--primary-teal)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 6px 24px rgba(15,95,95,0.3)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
          Save Changes
        </button>
      </form>
    </div>
  </div>
);
