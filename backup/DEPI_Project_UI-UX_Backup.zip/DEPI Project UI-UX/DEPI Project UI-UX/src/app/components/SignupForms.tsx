// Signup form components for Doctor and Admin

interface SignupFormProps {
  navigate: (page: string) => void;
}

// Doctor Signup Form
export const SignupDoctorPage = ({ navigate }: SignupFormProps) => (
  <div className="min-h-[calc(100vh-80px)] flex items-center justify-center px-5 py-10 animate-fadeIn"
       style={{ background: 'var(--hero-gradient)' }}>
    <div className="rounded-[24px] px-11 py-12 w-full max-w-[520px] transition-all duration-300"
         style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-lg)' }}>
      <a onClick={() => navigate('signup-role')}
         className="text-sm flex items-center gap-1.5 mb-4 cursor-pointer transition-all duration-300"
         style={{ color: 'var(--text-secondary)' }}
         onMouseEnter={(e) => {
           e.currentTarget.style.color = 'var(--primary-teal)';
         }}
         onMouseLeave={(e) => {
           e.currentTarget.style.color = 'var(--text-secondary)';
         }}>
        ← Back to role selection
      </a>
      <div className="text-center mb-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[13px] font-semibold mb-4"
             style={{ background: 'var(--bg-secondary)', border: '1px solid var(--primary-teal)', color: 'var(--primary-teal)' }}>
          👨‍⚕️ Doctor Account
        </div>
      </div>
      <h1 className="text-[32px] text-center mb-2"
          style={{ fontFamily: "'Playfair Display', serif", color: 'var(--primary-teal)' }}>
        Create Doctor Account
      </h1>
      <p className="text-center mb-8 text-[15px]" style={{ color: 'var(--text-secondary)' }}>
        Join our network of verified specialists
      </p>

      <form onSubmit={(e) => { e.preventDefault(); alert('Doctor account submitted for review! 🎉'); navigate('login'); }}>
        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>First Name</label>
            <input type="text" required placeholder="Sarah"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Last Name</label>
            <input type="text" required placeholder="Johnson"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Professional Email</label>
          <input type="email" required placeholder="doctor@clinic.com"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Phone Number</label>
          <input type="tel" required placeholder="+20 100 000 0000"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Medical Specialty</label>
          <select required
                  className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                  style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}>
            <option value="">Select your specialty...</option>
            <option>Cardiology</option>
            <option>Neurology</option>
            <option>Pediatrics</option>
            <option>Orthopedics</option>
            <option>Dermatology</option>
            <option>Ophthalmology</option>
            <option>Gynecology</option>
            <option>Psychiatry</option>
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>License Number</label>
            <input type="text" required placeholder="MED-12345"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Years of Experience</label>
            <input type="number" required placeholder="10" min="0"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Clinic / Hospital</label>
          <input type="text" required placeholder="Cairo Medical Center"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Consultation Fee (USD)</label>
          <input type="number" required placeholder="150" min="0"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Password</label>
          <input type="password" required placeholder="At least 8 characters"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Confirm Password</label>
          <input type="password" required placeholder="Re-enter your password"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <button type="submit"
                className="w-full py-4 rounded-full text-base font-bold transition-all duration-300 mt-3 border-none text-white"
                style={{ background: 'var(--primary-teal)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 6px 24px rgba(15,95,95,0.3)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
          Submit for Verification
        </button>
      </form>

      <p className="mt-6 text-sm text-center" style={{ color: 'var(--text-secondary)' }}>
        Already have an account? <a onClick={() => navigate('login')} className="font-bold cursor-pointer hover:underline" style={{ color: 'var(--primary-teal)' }}>Sign in</a>
      </p>
    </div>
  </div>
);

// Admin Signup Form
export const SignupAdminPage = ({ navigate }: SignupFormProps) => (
  <div className="min-h-[calc(100vh-80px)] flex items-center justify-center px-5 py-10 animate-fadeIn"
       style={{ background: 'var(--hero-gradient)' }}>
    <div className="rounded-[24px] px-11 py-12 w-full max-w-[520px] transition-all duration-300"
         style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-lg)' }}>
      <a onClick={() => navigate('signup-role')}
         className="text-sm flex items-center gap-1.5 mb-4 cursor-pointer transition-all duration-300"
         style={{ color: 'var(--text-secondary)' }}
         onMouseEnter={(e) => {
           e.currentTarget.style.color = 'var(--primary-teal)';
         }}
         onMouseLeave={(e) => {
           e.currentTarget.style.color = 'var(--text-secondary)';
         }}>
        ← Back to role selection
      </a>
      <div className="text-center mb-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[13px] font-semibold mb-4"
             style={{ background: 'var(--bg-secondary)', border: '1px solid var(--primary-teal)', color: 'var(--primary-teal)' }}>
          🔑 Admin Account
        </div>
      </div>
      <h1 className="text-[32px] text-center mb-2"
          style={{ fontFamily: "'Playfair Display', serif", color: 'var(--primary-teal)' }}>
        Create Admin Account
      </h1>
      <p className="text-center mb-8 text-[15px]" style={{ color: 'var(--text-secondary)' }}>
        Administrative access requires authorization
      </p>

      <form onSubmit={(e) => { e.preventDefault(); alert('Admin request sent for approval! 🎉'); navigate('login'); }}>
        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Full Name</label>
          <input type="text" required placeholder="Ahmed Bakr"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Work Email</label>
          <input type="email" required placeholder="admin@medicare.com"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Phone Number</label>
          <input type="tel" required placeholder="+20 100 000 0000"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Department / Role</label>
          <select required
                  className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                  style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}>
            <option value="">Select department...</option>
            <option>Operations</option>
            <option>IT & Technical Support</option>
            <option>Finance</option>
            <option>Customer Service</option>
            <option>Management</option>
          </select>
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Employee ID</label>
          <input type="text" required placeholder="EMP-00123"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Authorization Code</label>
          <input type="text" required placeholder="Provided by HR"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Password</label>
          <input type="password" required placeholder="At least 8 characters"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <div className="mb-5 text-left">
          <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Confirm Password</label>
          <input type="password" required placeholder="Re-enter your password"
                 className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                 style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                 onFocus={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                 }}
                 onBlur={(e) => {
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                   e.currentTarget.style.boxShadow = 'none';
                 }} />
        </div>

        <button type="submit"
                className="w-full py-4 rounded-full text-base font-bold transition-all duration-300 mt-3 border-none text-white"
                style={{ background: 'var(--primary-teal)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 6px 24px rgba(15,95,95,0.3)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
          Request Admin Access
        </button>
      </form>

      <p className="mt-6 text-sm text-center" style={{ color: 'var(--text-secondary)' }}>
        Already have an account? <a onClick={() => navigate('login')} className="font-bold cursor-pointer hover:underline" style={{ color: 'var(--primary-teal)' }}>Sign in</a>
      </p>
    </div>
  </div>
);
