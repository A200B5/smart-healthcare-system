import { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import '../styles/medicare-theme.css';
import { PatientHome, PatientDoctors, PatientAppointments, DoctorDashboard, DoctorProfile } from './components/Pages';
import { AdminDoctors, AdminUsers, AdminAppointments } from './components/AdminPages';
import { SignupDoctorPage, SignupAdminPage } from './components/SignupForms';

// Type definitions
type UserRole = 'patient' | 'doctor' | 'admin';
type Page = 'home' | 'login' | 'signup-role' | 'signup-patient' | 'signup-doctor' | 'signup-admin' |
  'patient-home' | 'patient-doctors' | 'patient-appointments' |
  'doctor-dashboard' | 'doctor-profile' |
  'admin-dashboard' | 'admin-doctors' | 'admin-users' | 'admin-appointments';

interface User {
  email: string;
  password: string;
  role: UserRole;
  name: string;
  initial: string;
  redirectTo: Page;
}

// Predefined user accounts
const USERS: Record<string, User> = {
  'sabry56030@gamil.com': {
    email: 'sabry56030@gamil.com',
    password: 'Asabry753#159',
    role: 'patient',
    name: 'Sabry Ahmed',
    initial: 'S',
    redirectTo: 'patient-home'
  },
  'ahmedsabry8818@gamil.com': {
    email: 'ahmedsabry8818@gamil.com',
    password: 'Asabry753##159',
    role: 'admin',
    name: 'Ahmed Sabry',
    initial: 'A',
    redirectTo: 'admin-dashboard'
  },
  'ahmedbakr8818@gamil.com': {
    email: 'ahmedbakr8818@gamil.com',
    password: 'Asabry753###159',
    role: 'doctor',
    name: 'Dr. Ahmed Bakr',
    initial: 'B',
    redirectTo: 'doctor-dashboard'
  }
};

// Chart data for admin dashboard
const monthlyAppointmentsData = [
  { month: 'Jan', appointments: 45, patients: 38 },
  { month: 'Feb', appointments: 52, patients: 44 },
  { month: 'Mar', appointments: 61, patients: 51 },
  { month: 'Apr', appointments: 58, patients: 49 },
  { month: 'May', appointments: 67, patients: 58 },
  { month: 'Jun', appointments: 71, patients: 62 }
];

const statusBreakdownData = [
  { name: 'Confirmed', value: 35, color: '#10B981' },
  { name: 'Pending', value: 25, color: '#F59E0B' },
  { name: 'Completed', value: 30, color: '#3B82F6' },
  { name: 'Rejected', value: 10, color: '#EF4444' }
];

const revenueData = [
  { month: 'Jan', revenue: 68500 },
  { month: 'Feb', revenue: 73200 },
  { month: 'Mar', revenue: 79800 },
  { month: 'Apr', revenue: 85100 },
  { month: 'May', revenue: 89400 },
  { month: 'Jun', revenue: 94500 }
];

const specialtyData = [
  { specialty: 'Cardiology', count: 12 },
  { specialty: 'Neurology', count: 8 },
  { specialty: 'Pediatrics', count: 15 },
  { specialty: 'Orthopedics', count: 10 },
  { specialty: 'Dermatology', count: 11 },
  { specialty: 'Other', count: 9 }
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [loginError, setLoginError] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);

  // Theme management
  useEffect(() => {
    const saved = localStorage.getItem('theme');
    if (saved === 'dark') {
      setTheme('dark');
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
  };

  // Navigation
  const navigate = (page: Page) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentPage(page);
  };

  // Authentication
  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const email = (form.elements.namedItem('email') as HTMLInputElement).value.trim().toLowerCase();
    const password = (form.elements.namedItem('password') as HTMLInputElement).value;

    setLoginError(false);
    setLoginSuccess(false);

    const user = USERS[email];

    if (user && user.password === password) {
      setCurrentUser(user);
      setLoginSuccess(true);

      setTimeout(() => {
        navigate(user.redirectTo);
        setLoginSuccess(false);
        form.reset();
      }, 1200);
    } else {
      setLoginError(true);
      setTimeout(() => setLoginError(false), 4000);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    navigate('home');
  };

  // Navbar Components
  const PublicNavbar = () => (
    <nav className="flex items-center justify-between px-16 h-20 sticky top-0 z-[1000] transition-all duration-300"
         style={{ background: 'var(--navbar-bg)', boxShadow: 'var(--navbar-shadow)' }}>
      <div className="text-[22px] font-bold flex items-center gap-2 cursor-pointer transition-all duration-300 hover:opacity-80"
           style={{ color: 'var(--primary-teal)' }}
           onClick={() => navigate('home')}>
        <span className="text-[28px]">🏥</span> MediCare Pro
      </div>
      <div className="flex gap-3 items-center">
        <button onClick={toggleTheme}
                className="w-11 h-11 rounded-full flex items-center justify-center text-xl transition-all duration-300 hover:rotate-[15deg]"
                style={{ background: 'var(--bg-secondary)', border: '2px solid var(--border-color)', color: 'var(--text-primary)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.color = 'white';
                  e.currentTarget.style.borderColor = 'var(--primary-teal)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--bg-secondary)';
                  e.currentTarget.style.color = 'var(--text-primary)';
                  e.currentTarget.style.borderColor = 'var(--border-color)';
                }}>
          {theme === 'light' ? '🌙' : '☀️'}
        </button>
        <button onClick={() => navigate('login')}
                className="px-7 py-3 rounded-full text-[15px] font-semibold transition-all duration-300 border-2"
                style={{ background: 'transparent', borderColor: 'var(--primary-teal)', color: 'var(--primary-teal)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'var(--primary-teal)';
                }}>
          Login
        </button>
        <button onClick={() => navigate('signup-role')}
                className="px-7 py-3 rounded-full text-[15px] font-semibold transition-all duration-300 border-2 text-white"
                style={{ background: 'var(--primary-teal)', borderColor: 'var(--primary-teal)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal-dark)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}>
          Sign Up
        </button>
      </div>
    </nav>
  );

  const PatientNavbar = () => (
    <nav className="flex items-center justify-between px-16 h-20 sticky top-0 z-[1000] transition-all duration-300"
         style={{ background: 'var(--navbar-bg)', boxShadow: 'var(--navbar-shadow)' }}>
      <div className="text-[22px] font-bold flex items-center gap-2 cursor-pointer transition-all duration-300 hover:opacity-80"
           style={{ color: 'var(--primary-teal)' }}
           onClick={() => navigate('patient-home')}>
        <span className="text-[28px]">🏥</span> MediCare Pro
      </div>
      <ul className="flex items-center gap-2 list-none">
        <li><a onClick={() => navigate('patient-doctors')}
               className="px-[22px] py-[10px] rounded-full text-[15px] font-medium cursor-pointer transition-all duration-300"
               style={{
                 color: currentPage === 'patient-doctors' ? 'var(--primary-teal)' : 'var(--text-secondary)',
                 background: currentPage === 'patient-doctors' ? 'var(--bg-secondary)' : 'transparent',
                 fontWeight: currentPage === 'patient-doctors' ? 600 : 500
               }}
               onMouseEnter={(e) => {
                 if (currentPage !== 'patient-doctors') {
                   e.currentTarget.style.color = 'var(--primary-teal)';
                   e.currentTarget.style.background = 'var(--bg-secondary)';
                 }
               }}
               onMouseLeave={(e) => {
                 if (currentPage !== 'patient-doctors') {
                   e.currentTarget.style.color = 'var(--text-secondary)';
                   e.currentTarget.style.background = 'transparent';
                 }
               }}>
          Find Doctors
        </a></li>
        <li><a onClick={() => navigate('patient-appointments')}
               className="px-[22px] py-[10px] rounded-full text-[15px] font-medium cursor-pointer transition-all duration-300"
               style={{
                 color: currentPage === 'patient-appointments' ? 'var(--primary-teal)' : 'var(--text-secondary)',
                 background: currentPage === 'patient-appointments' ? 'var(--bg-secondary)' : 'transparent',
                 fontWeight: currentPage === 'patient-appointments' ? 600 : 500
               }}
               onMouseEnter={(e) => {
                 if (currentPage !== 'patient-appointments') {
                   e.currentTarget.style.color = 'var(--primary-teal)';
                   e.currentTarget.style.background = 'var(--bg-secondary)';
                 }
               }}
               onMouseLeave={(e) => {
                 if (currentPage !== 'patient-appointments') {
                   e.currentTarget.style.color = 'var(--text-secondary)';
                   e.currentTarget.style.background = 'transparent';
                 }
               }}>
          My Appointments
        </a></li>
      </ul>
      <div className="flex gap-3 items-center">
        <button onClick={toggleTheme}
                className="w-11 h-11 rounded-full flex items-center justify-center text-xl transition-all duration-300 hover:rotate-[15deg]"
                style={{ background: 'var(--bg-secondary)', border: '2px solid var(--border-color)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.color = 'white';
                  e.currentTarget.style.borderColor = 'var(--primary-teal)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--bg-secondary)';
                  e.currentTarget.style.color = 'var(--text-primary)';
                  e.currentTarget.style.borderColor = 'var(--border-color)';
                }}>
          {theme === 'light' ? '🌙' : '☀️'}
        </button>
        <div className="flex items-center gap-[10px] px-[14px] py-[6px] rounded-full border-2"
             style={{ background: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-base font-bold text-white"
               style={{ background: 'var(--primary-teal)' }}>
            {currentUser?.initial}
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{currentUser?.name}</div>
            <div className="text-[11px] font-bold uppercase" style={{ color: 'var(--primary-teal)' }}>Patient</div>
          </div>
        </div>
        <button onClick={logout}
                className="px-5 py-[10px] rounded-full text-sm font-semibold transition-all duration-300 border-2"
                style={{ background: 'transparent', borderColor: 'var(--rejected)', color: 'var(--rejected)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--rejected)';
                  e.currentTarget.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'var(--rejected)';
                }}>
          Logout
        </button>
      </div>
    </nav>
  );

  const DoctorNavbar = () => (
    <nav className="flex items-center justify-between px-16 h-20 sticky top-0 z-[1000] transition-all duration-300"
         style={{ background: 'var(--navbar-bg)', boxShadow: 'var(--navbar-shadow)' }}>
      <div className="text-[22px] font-bold flex items-center gap-2 cursor-pointer transition-all duration-300 hover:opacity-80"
           style={{ color: 'var(--primary-teal)' }}
           onClick={() => navigate('doctor-dashboard')}>
        <span className="text-[28px]">🏥</span> MediCare Pro
      </div>
      <ul className="flex items-center gap-2 list-none">
        <li><a onClick={() => navigate('doctor-dashboard')}
               className="px-[22px] py-[10px] rounded-full text-[15px] font-medium cursor-pointer transition-all duration-300"
               style={{
                 color: currentPage === 'doctor-dashboard' ? 'var(--primary-teal)' : 'var(--text-secondary)',
                 background: currentPage === 'doctor-dashboard' ? 'var(--bg-secondary)' : 'transparent',
                 fontWeight: currentPage === 'doctor-dashboard' ? 600 : 500
               }}
               onMouseEnter={(e) => {
                 if (currentPage !== 'doctor-dashboard') {
                   e.currentTarget.style.color = 'var(--primary-teal)';
                   e.currentTarget.style.background = 'var(--bg-secondary)';
                 }
               }}
               onMouseLeave={(e) => {
                 if (currentPage !== 'doctor-dashboard') {
                   e.currentTarget.style.color = 'var(--text-secondary)';
                   e.currentTarget.style.background = 'transparent';
                 }
               }}>
          Dashboard
        </a></li>
        <li><a onClick={() => navigate('doctor-profile')}
               className="px-[22px] py-[10px] rounded-full text-[15px] font-medium cursor-pointer transition-all duration-300"
               style={{
                 color: currentPage === 'doctor-profile' ? 'var(--primary-teal)' : 'var(--text-secondary)',
                 background: currentPage === 'doctor-profile' ? 'var(--bg-secondary)' : 'transparent',
                 fontWeight: currentPage === 'doctor-profile' ? 600 : 500
               }}
               onMouseEnter={(e) => {
                 if (currentPage !== 'doctor-profile') {
                   e.currentTarget.style.color = 'var(--primary-teal)';
                   e.currentTarget.style.background = 'var(--bg-secondary)';
                 }
               }}
               onMouseLeave={(e) => {
                 if (currentPage !== 'doctor-profile') {
                   e.currentTarget.style.color = 'var(--text-secondary)';
                   e.currentTarget.style.background = 'transparent';
                 }
               }}>
          My Profile
        </a></li>
      </ul>
      <div className="flex gap-3 items-center">
        <button onClick={toggleTheme}
                className="w-11 h-11 rounded-full flex items-center justify-center text-xl transition-all duration-300 hover:rotate-[15deg]"
                style={{ background: 'var(--bg-secondary)', border: '2px solid var(--border-color)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.color = 'white';
                  e.currentTarget.style.borderColor = 'var(--primary-teal)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--bg-secondary)';
                  e.currentTarget.style.color = 'var(--text-primary)';
                  e.currentTarget.style.borderColor = 'var(--border-color)';
                }}>
          {theme === 'light' ? '🌙' : '☀️'}
        </button>
        <div className="flex items-center gap-[10px] px-[14px] py-[6px] rounded-full border-2"
             style={{ background: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-base font-bold text-white bg-[#3B82F6]">
            👨‍⚕️
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{currentUser?.name}</div>
            <div className="text-[11px] font-bold uppercase" style={{ color: 'var(--primary-teal)' }}>Doctor</div>
          </div>
        </div>
        <button onClick={logout}
                className="px-5 py-[10px] rounded-full text-sm font-semibold transition-all duration-300 border-2"
                style={{ background: 'transparent', borderColor: 'var(--rejected)', color: 'var(--rejected)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--rejected)';
                  e.currentTarget.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'var(--rejected)';
                }}>
          Logout
        </button>
      </div>
    </nav>
  );

  const AdminNavbar = () => (
    <nav className="flex items-center justify-between px-16 h-20 sticky top-0 z-[1000] transition-all duration-300"
         style={{ background: 'var(--navbar-bg)', boxShadow: 'var(--navbar-shadow)' }}>
      <div className="text-[22px] font-bold flex items-center gap-2 cursor-pointer transition-all duration-300 hover:opacity-80"
           style={{ color: 'var(--primary-teal)' }}
           onClick={() => navigate('admin-dashboard')}>
        <span className="text-[28px]">🏥</span> MediCare Pro
      </div>
      <ul className="flex items-center gap-2 list-none">
        {[
          { page: 'admin-dashboard', label: 'Dashboard' },
          { page: 'admin-doctors', label: 'Doctors' },
          { page: 'admin-users', label: 'Users' },
          { page: 'admin-appointments', label: 'Appointments' }
        ].map((item) => (
          <li key={item.page}>
            <a onClick={() => navigate(item.page as Page)}
               className="px-[22px] py-[10px] rounded-full text-[15px] font-medium cursor-pointer transition-all duration-300"
               style={{
                 color: currentPage === item.page ? 'var(--primary-teal)' : 'var(--text-secondary)',
                 background: currentPage === item.page ? 'var(--bg-secondary)' : 'transparent',
                 fontWeight: currentPage === item.page ? 600 : 500
               }}
               onMouseEnter={(e) => {
                 if (currentPage !== item.page) {
                   e.currentTarget.style.color = 'var(--primary-teal)';
                   e.currentTarget.style.background = 'var(--bg-secondary)';
                 }
               }}
               onMouseLeave={(e) => {
                 if (currentPage !== item.page) {
                   e.currentTarget.style.color = 'var(--text-secondary)';
                   e.currentTarget.style.background = 'transparent';
                 }
               }}>
              {item.label}
            </a>
          </li>
        ))}
      </ul>
      <div className="flex gap-3 items-center">
        <button onClick={toggleTheme}
                className="w-11 h-11 rounded-full flex items-center justify-center text-xl transition-all duration-300 hover:rotate-[15deg]"
                style={{ background: 'var(--bg-secondary)', border: '2px solid var(--border-color)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--primary-teal)';
                  e.currentTarget.style.color = 'white';
                  e.currentTarget.style.borderColor = 'var(--primary-teal)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--bg-secondary)';
                  e.currentTarget.style.color = 'var(--text-primary)';
                  e.currentTarget.style.borderColor = 'var(--border-color)';
                }}>
          {theme === 'light' ? '🌙' : '☀️'}
        </button>
        <div className="flex items-center gap-[10px] px-[14px] py-[6px] rounded-full border-2"
             style={{ background: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-base font-bold text-white"
               style={{ background: 'var(--accent-gold)' }}>
            🔑
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{currentUser?.name}</div>
            <div className="text-[11px] font-bold uppercase" style={{ color: 'var(--primary-teal)' }}>Admin</div>
          </div>
        </div>
        <button onClick={logout}
                className="px-5 py-[10px] rounded-full text-sm font-semibold transition-all duration-300 border-2"
                style={{ background: 'transparent', borderColor: 'var(--rejected)', color: 'var(--rejected)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--rejected)';
                  e.currentTarget.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'var(--rejected)';
                }}>
          Logout
        </button>
      </div>
    </nav>
  );

  // Render appropriate navbar
  const renderNavbar = () => {
    if (!currentUser) return <PublicNavbar />;
    switch (currentUser.role) {
      case 'patient': return <PatientNavbar />;
      case 'doctor': return <DoctorNavbar />;
      case 'admin': return <AdminNavbar />;
      default: return <PublicNavbar />;
    }
  };

  // Page Components
  const HomePage = () => (
    <div className="animate-fadeIn">
      <section className="min-h-[600px] px-16 py-[100px] flex items-center justify-between gap-[60px] relative overflow-hidden"
               style={{ background: 'var(--hero-gradient)' }}>
        <div className="absolute top-[-50%] right-[-20%] w-[600px] h-[600px] rounded-full pointer-events-none"
             style={{ background: 'radial-gradient(circle, rgba(245,166,35,0.08) 0%, transparent 70%)' }}></div>
        <div className="max-w-[560px] z-[2]">
          <div className="inline-flex items-center gap-2 px-6 py-[10px] rounded-full text-sm font-medium mb-8"
               style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.9)' }}>
            <span>🏆</span> Egypt's #1 Healthcare Platform
          </div>
          <h1 className="text-[64px] leading-[1.1] mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            <span className="text-white">Your Health,</span><br/>
            <span style={{ color: 'var(--accent-gold)' }}>Our Priority</span>
          </h1>
          <p className="text-lg mb-10 max-w-[480px]" style={{ color: 'rgba(255,255,255,0.75)', lineHeight: '1.7' }}>
            Book appointments with Egypt's top specialists. Smart scheduling, instant confirmation, and seamless healthcare management.
          </p>
          <div className="flex gap-4 flex-wrap">
            <button onClick={() => navigate('signup-role')}
                    className="px-12 py-3 rounded-full text-[15px] font-bold transition-all duration-300 border-2"
                    style={{ background: 'var(--accent-gold)', color: '#0A2540', borderColor: 'var(--accent-gold)' }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'var(--accent-gold-hover)';
                      e.currentTarget.style.transform = 'translateY(-2px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'var(--accent-gold)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}>
              Get Started Free
            </button>
            <button onClick={() => navigate('login')}
                    className="px-7 py-3 rounded-full text-[15px] font-semibold transition-all duration-300 border-2 text-white"
                    style={{ background: 'transparent', borderColor: 'rgba(255,255,255,0.4)' }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.1)';
                      e.currentTarget.style.borderColor = 'white';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.4)';
                    }}>
              Sign In
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-5 z-[2]">
          {[
            { number: '500+', label: 'Expert Doctors' },
            { number: '50K+', label: 'Happy Patients' },
            { number: '98%', label: 'Satisfaction Rate' },
            { number: '24/7', label: 'Support Available' }
          ].map((stat, i) => (
            <div key={i}
                 className="min-w-[200px] rounded-[20px] px-10 py-9 text-center transition-all duration-300 cursor-default"
                 style={{ background: 'rgba(255,255,255,0.08)', backdropFilter: 'blur(16px)',
                          border: '1px solid rgba(255,255,255,0.12)' }}
                 onMouseEnter={(e) => {
                   e.currentTarget.style.background = 'rgba(255,255,255,0.14)';
                   e.currentTarget.style.transform = 'translateY(-4px)';
                 }}
                 onMouseLeave={(e) => {
                   e.currentTarget.style.background = 'rgba(255,255,255,0.08)';
                   e.currentTarget.style.transform = 'translateY(0)';
                 }}>
              <div className="text-5xl font-extrabold leading-none mb-2" style={{ color: 'var(--accent-gold)' }}>
                {stat.number}
              </div>
              <div className="text-[15px] font-medium" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="px-16 py-[100px] transition-all duration-300" style={{ background: 'var(--bg-primary)' }}>
        <h2 className="text-[40px] font-bold text-center mb-3"
            style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
          Medical Specialties
        </h2>
        <p className="text-lg text-center mb-14" style={{ color: 'var(--text-secondary)' }}>
          Find the right specialist for your needs
        </p>
        <div className="flex flex-wrap justify-center gap-[14px] max-w-[900px] mx-auto">
          {['Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics', 'Dermatology', 'Ophthalmology', 'Gynecology', 'Psychiatry'].map((spec, i) => (
            <div key={i}
                 className="px-7 py-3 rounded-full border-2 text-[15px] font-medium cursor-pointer transition-all duration-300"
                 style={{
                   borderColor: i === 1 ? 'var(--primary-teal)' : 'var(--border-color)',
                   background: i === 1 ? 'var(--bg-secondary)' : 'var(--bg-card)',
                   color: i === 1 ? 'var(--primary-teal)' : 'var(--text-primary)'
                 }}
                 onMouseEnter={(e) => {
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                   e.currentTarget.style.color = 'var(--primary-teal)';
                   e.currentTarget.style.background = 'var(--bg-secondary)';
                   e.currentTarget.style.transform = 'translateY(-2px)';
                 }}
                 onMouseLeave={(e) => {
                   if (i !== 1) {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.color = 'var(--text-primary)';
                     e.currentTarget.style.background = 'var(--bg-card)';
                   } else {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.color = 'var(--primary-teal)';
                     e.currentTarget.style.background = 'var(--bg-secondary)';
                   }
                   e.currentTarget.style.transform = 'translateY(0)';
                 }}>
              {spec}
            </div>
          ))}
        </div>
      </section>

      <section className="px-16 py-[100px] transition-all duration-300" style={{ background: 'var(--bg-secondary)' }}>
        <h2 className="text-[40px] font-bold text-center mb-3"
            style={{ fontFamily: "'Playfair Display', serif", color: 'var(--text-primary)' }}>
          How It Works
        </h2>
        <p className="text-lg text-center mb-14" style={{ color: 'var(--text-secondary)' }}>
          Book your appointment in 3 simple steps
        </p>
        <div className="grid grid-cols-3 gap-8 max-w-[1100px] mx-auto">
          {[
            { num: '01', icon: '🔍', title: 'Find Your Doctor', desc: 'Browse our network of verified specialists filtered by specialty, rating, and availability.' },
            { num: '02', icon: '📅', title: 'Book Appointment', desc: 'Choose your preferred date and time slot. Get instant confirmation via email.' },
            { num: '03', icon: '✅', title: 'Get Treatment', desc: 'Visit the doctor and receive the care you deserve. Track your health history.' }
          ].map((step, i) => (
            <div key={i}
                 className="rounded-[20px] px-9 py-12 text-center relative overflow-hidden transition-all duration-300 border cursor-default"
                 style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
                 onMouseEnter={(e) => {
                   e.currentTarget.style.transform = 'translateY(-6px)';
                   e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
                   e.currentTarget.style.borderColor = 'var(--primary-teal)';
                 }}
                 onMouseLeave={(e) => {
                   e.currentTarget.style.transform = 'translateY(0)';
                   e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
                   e.currentTarget.style.borderColor = 'var(--border-color)';
                 }}>
              <div className="absolute top-4 right-6 text-[100px] font-extrabold leading-none opacity-30"
                   style={{ fontFamily: "'Playfair Display', serif", color: 'var(--border-color)' }}>
                {step.num}
              </div>
              <div className="text-5xl mb-5 relative z-[2]">{step.icon}</div>
              <h3 className="text-[22px] font-bold mb-4 relative z-[2]" style={{ color: 'var(--text-primary)' }}>
                {step.title}
              </h3>
              <p className="text-[15px] leading-[1.7] relative z-[2]" style={{ color: 'var(--text-secondary)' }}>
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="px-16 py-[100px] text-center" style={{ background: 'var(--cta-gradient)' }}>
        <h2 className="text-[44px] leading-[1.2] text-white mb-5" style={{ fontFamily: "'Playfair Display', serif" }}>
          Ready to Take Control of<br/>Your Health?
        </h2>
        <p className="text-lg mb-10 max-w-[550px] mx-auto" style={{ color: 'rgba(255,255,255,0.75)' }}>
          Join thousands of patients who trust MediCare Pro for their healthcare needs.
        </p>
        <button onClick={() => navigate('signup-role')}
                className="px-12 py-[18px] rounded-full text-[17px] font-bold transition-all duration-300 border-none"
                style={{ background: 'var(--accent-gold)', color: '#0A2540' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-3px)';
                  e.currentTarget.style.boxShadow = '0 8px 30px rgba(245,166,35,0.4)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
          Create Free Account
        </button>
      </section>

      <footer className="px-16 py-10 text-center" style={{ background: 'var(--footer-bg)' }}>
        <div className="text-lg text-white font-semibold mb-2">
          🏥 MediCare Pro — Smart Healthcare Management System
        </div>
        <p className="text-[13px]" style={{ color: 'var(--footer-text)' }}>
          © 2025 Built by Ahmed Bakr, Ahmed Sabry, Ibrahim Mohamed & Ahmed Hany
        </p>
      </footer>
    </div>
  );

  const LoginPage = () => (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center px-5 py-10 animate-fadeIn"
         style={{ background: 'var(--hero-gradient)' }}>
      <div className="rounded-[24px] px-11 py-12 w-full max-w-[520px] transition-all duration-300"
           style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-lg)' }}>
        <div className="text-[56px] mb-4 text-center">🏥</div>
        <h1 className="text-[32px] text-center mb-2"
            style={{ fontFamily: "'Playfair Display', serif", color: 'var(--primary-teal)' }}>
          Welcome Back
        </h1>
        <p className="text-center mb-8 text-[15px]" style={{ color: 'var(--text-secondary)' }}>
          Sign in to your MediCare Pro account
        </p>

        {loginError && (
          <div className="flex items-center gap-2 px-4 py-3 rounded-[10px] mb-4 text-sm font-medium animate-shake"
               style={{ background: 'var(--rejected-bg)', color: 'var(--rejected)', border: '1px solid var(--rejected)' }}>
            ⚠️ <span>Invalid email or password. Please try again.</span>
          </div>
        )}

        {loginSuccess && (
          <div className="flex items-center gap-2 px-4 py-3 rounded-[10px] mb-4 text-sm font-medium"
               style={{ background: 'var(--confirmed-bg)', color: 'var(--confirmed)', border: '1px solid var(--confirmed)' }}>
            ✅ <span>Welcome {currentUser?.name}! Redirecting to {currentUser?.role} dashboard...</span>
          </div>
        )}

        <form onSubmit={handleLogin}>
          <div className="mb-5 text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>
              Email Address
            </label>
            <input type="email" name="email" required placeholder="you@example.com"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="mb-5 text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>
              Password
            </label>
            <input type="password" name="password" required placeholder="••••••••"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <button type="submit"
                  className="w-full py-4 rounded-full text-base font-bold transition-all duration-300 mt-3 border-none text-white"
                  style={{ background: 'var(--primary-teal)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 6px 24px rgba(15,95,95,0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}>
            Sign In
          </button>
        </form>

        <div className="flex items-center gap-3 my-7 text-[13px]" style={{ color: 'var(--text-secondary)' }}>
          <div className="flex-1 h-px" style={{ background: 'var(--border-color)' }}></div>
          OR CONTINUE WITH
          <div className="flex-1 h-px" style={{ background: 'var(--border-color)' }}></div>
        </div>

        <div className="flex flex-col gap-3">
          <button className="w-full py-[14px] rounded-xl text-[15px] font-semibold flex items-center justify-center gap-3 border-2 transition-all duration-300"
                  style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}>
            Continue with Google
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
          </button>
          <button className="w-full py-[14px] rounded-xl text-[15px] font-semibold flex items-center justify-center gap-3 border-2 transition-all duration-300"
                  style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}>
            Continue with Facebook
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="#1877F2">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
          </button>
        </div>

        <p className="mt-6 text-sm text-center" style={{ color: 'var(--text-secondary)' }}>
          Don't have an account? <a onClick={() => navigate('signup-role')} className="font-bold cursor-pointer hover:underline" style={{ color: 'var(--primary-teal)' }}>Sign up</a>
        </p>
      </div>
    </div>
  );

  const SignupRolePage = () => (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center px-5 py-10 animate-fadeIn"
         style={{ background: 'var(--hero-gradient)' }}>
      <div className="rounded-[24px] px-11 py-12 w-full max-w-[520px] transition-all duration-300"
           style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-lg)' }}>
        <div className="text-[56px] mb-4 text-center">👋</div>
        <h1 className="text-[32px] text-center mb-2"
            style={{ fontFamily: "'Playfair Display', serif", color: 'var(--primary-teal)' }}>
          Join MediCare Pro
        </h1>
        <p className="text-center mb-8 text-[15px]" style={{ color: 'var(--text-secondary)' }}>
          Choose your account type to get started
        </p>

        <div className="grid gap-[14px] mb-6">
          {[
            { role: 'patient', icon: '🧑', name: 'Patient', desc: 'Book appointments and manage your health' },
            { role: 'doctor', icon: '👨‍⚕️', name: 'Doctor', desc: 'Manage your practice and patient appointments' },
            { role: 'admin', icon: '🔑', name: 'Admin', desc: 'Manage the platform and oversee operations' }
          ].map((item) => (
            <div key={item.role}
                 onClick={() => setSelectedRole(item.role as UserRole)}
                 className="flex items-center gap-4 px-[22px] py-[18px] rounded-[14px] border-2 cursor-pointer transition-all duration-300"
                 style={{
                   borderColor: selectedRole === item.role ? 'var(--primary-teal)' : 'var(--border-color)',
                   background: selectedRole === item.role ? 'var(--bg-secondary)' : 'var(--bg-input)',
                   boxShadow: selectedRole === item.role ? '0 0 0 4px rgba(15,95,95,0.1)' : 'none'
                 }}
                 onMouseEnter={(e) => {
                   if (selectedRole !== item.role) {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.transform = 'translateX(4px)';
                   }
                 }}
                 onMouseLeave={(e) => {
                   if (selectedRole !== item.role) {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.transform = 'translateX(0)';
                   }
                 }}>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 text-white"
                   style={{ background: 'var(--primary-teal)' }}>
                {item.icon}
              </div>
              <div className="flex-1">
                <div className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>{item.name}</div>
                <div className="text-[13px] mt-0.5" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
              </div>
              <div className="w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300"
                   style={{
                     borderColor: selectedRole === item.role ? 'var(--primary-teal)' : 'var(--border-color)',
                     background: selectedRole === item.role ? 'var(--primary-teal)' : 'transparent',
                     color: selectedRole === item.role ? 'white' : 'transparent'
                   }}>
                {selectedRole === item.role && <span className="font-bold">✓</span>}
              </div>
            </div>
          ))}
        </div>

        <button onClick={() => selectedRole && navigate(`signup-${selectedRole}` as Page)}
                disabled={!selectedRole}
                className="w-full py-4 rounded-full text-base font-bold transition-all duration-300 mt-3 border-none text-white"
                style={{
                  background: 'var(--primary-teal)',
                  opacity: selectedRole ? 1 : 0.5,
                  pointerEvents: selectedRole ? 'auto' : 'none'
                }}
                onMouseEnter={(e) => {
                  if (selectedRole) {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 6px 24px rgba(15,95,95,0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
          Continue
        </button>

        <p className="mt-6 text-sm text-center" style={{ color: 'var(--text-secondary)' }}>
          Already have an account? <a onClick={() => navigate('login')} className="font-bold cursor-pointer hover:underline" style={{ color: 'var(--primary-teal)' }}>Sign in</a>
        </p>
      </div>
    </div>
  );

  // Continue in next part due to length...
  const SignupPatientPage = () => (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center px-5 py-10 animate-fadeIn"
         style={{ background: 'var(--hero-gradient)' }}>
      <div className="rounded-[24px] px-11 py-12 w-full max-w-[520px] transition-all duration-300"
           style={{ background: 'var(--bg-card)', boxShadow: 'var(--shadow-lg)' }}>
        <a onClick={() => navigate('signup-role')}
           className="text-sm flex items-center gap-1.5 mb-4 cursor-pointer transition-all duration-300"
           style={{ color: 'var(--text-secondary)' }}
           onMouseEnter={(e) => {
             e.currentTarget.style.color = 'var(--primary-teal)';
           }}
           onMouseLeave={(e) => {
             e.currentTarget.style.color = 'var(--text-secondary)';
           }}>
          ← Back to role selection
        </a>
        <div className="text-center mb-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[13px] font-semibold mb-4"
               style={{ background: 'var(--bg-secondary)', border: '1px solid var(--primary-teal)', color: 'var(--primary-teal)' }}>
            🧑 Patient Account
          </div>
        </div>
        <h1 className="text-[32px] text-center mb-2"
            style={{ fontFamily: "'Playfair Display', serif", color: 'var(--primary-teal)' }}>
          Create Patient Account
        </h1>
        <p className="text-center mb-8 text-[15px]" style={{ color: 'var(--text-secondary)' }}>
          Fill in your details to get started
        </p>

        <form onSubmit={(e) => { e.preventDefault(); alert('Patient account created! 🎉'); navigate('login'); }}>
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div className="text-left">
              <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>First Name</label>
              <input type="text" required placeholder="John"
                     className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                     style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                     onFocus={(e) => {
                       e.currentTarget.style.borderColor = 'var(--primary-teal)';
                       e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                     }}
                     onBlur={(e) => {
                       e.currentTarget.style.borderColor = 'var(--border-color)';
                       e.currentTarget.style.boxShadow = 'none';
                     }} />
            </div>
            <div className="text-left">
              <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Last Name</label>
              <input type="text" required placeholder="Doe"
                     className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                     style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                     onFocus={(e) => {
                       e.currentTarget.style.borderColor = 'var(--primary-teal)';
                       e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                     }}
                     onBlur={(e) => {
                       e.currentTarget.style.borderColor = 'var(--border-color)';
                       e.currentTarget.style.boxShadow = 'none';
                     }} />
            </div>
          </div>
          <div className="mb-5 text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Email Address</label>
            <input type="email" required placeholder="patient@email.com"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="mb-5 text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Phone Number</label>
            <input type="tel" required placeholder="+20 100 000 0000"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div className="text-left">
              <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Date of Birth</label>
              <input type="date" required
                     className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                     style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                     onFocus={(e) => {
                       e.currentTarget.style.borderColor = 'var(--primary-teal)';
                       e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                     }}
                     onBlur={(e) => {
                       e.currentTarget.style.borderColor = 'var(--border-color)';
                       e.currentTarget.style.boxShadow = 'none';
                     }} />
            </div>
            <div className="text-left">
              <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Gender</label>
              <select required
                      className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                      style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = 'var(--primary-teal)';
                        e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border-color)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}>
                <option value="">Select...</option>
                <option>Male</option>
                <option>Female</option>
              </select>
            </div>
          </div>
          <div className="mb-5 text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Password</label>
            <input type="password" required placeholder="At least 8 characters"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <div className="mb-5 text-left">
            <label className="block text-[13px] font-semibold mb-2" style={{ color: 'var(--primary-teal)' }}>Confirm Password</label>
            <input type="password" required placeholder="Re-enter your password"
                   className="w-full px-[18px] py-[14px] rounded-xl text-[15px] border-2 outline-none transition-all duration-300"
                   style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                   onFocus={(e) => {
                     e.currentTarget.style.borderColor = 'var(--primary-teal)';
                     e.currentTarget.style.boxShadow = '0 0 0 4px rgba(15,95,95,0.1)';
                   }}
                   onBlur={(e) => {
                     e.currentTarget.style.borderColor = 'var(--border-color)';
                     e.currentTarget.style.boxShadow = 'none';
                   }} />
          </div>
          <button type="submit"
                  className="w-full py-4 rounded-full text-base font-bold transition-all duration-300 mt-3 border-none text-white"
                  style={{ background: 'var(--primary-teal)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 6px 24px rgba(15,95,95,0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}>
            Create Patient Account
          </button>
        </form>

        <div className="flex items-center gap-3 my-7 text-[13px]" style={{ color: 'var(--text-secondary)' }}>
          <div className="flex-1 h-px" style={{ background: 'var(--border-color)' }}></div>
          OR SIGN UP WITH
          <div className="flex-1 h-px" style={{ background: 'var(--border-color)' }}></div>
        </div>

        <div className="flex flex-col gap-3">
          <button className="w-full py-[14px] rounded-xl text-[15px] font-semibold flex items-center justify-center gap-3 border-2 transition-all duration-300"
                  style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}>
            Continue with Google
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
          </button>
          <button className="w-full py-[14px] rounded-xl text-[15px] font-semibold flex items-center justify-center gap-3 border-2 transition-all duration-300"
                  style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--primary-teal)';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}>
            Continue with Facebook
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="#1877F2">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
          </button>
        </div>

        <p className="mt-6 text-sm text-center" style={{ color: 'var(--text-secondary)' }}>
          Already have an account? <a onClick={() => navigate('login')} className="font-bold cursor-pointer hover:underline" style={{ color: 'var(--primary-teal)' }}>Sign in</a>
        </p>
      </div>
    </div>
  );

  // Due to file length limitations, I'll create the remaining components in a separate file
  // For now, let me continue with key pages...

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home': return <HomePage />;
      case 'login': return <LoginPage />;
      case 'signup-role': return <SignupRolePage />;
      case 'signup-patient': return <SignupPatientPage />;
      case 'patient-home': return <PatientHome navigate={navigate} currentUser={currentUser} />;
      case 'patient-doctors': return <PatientDoctors navigate={navigate} currentUser={currentUser} />;
      case 'patient-appointments': return <PatientAppointments navigate={navigate} currentUser={currentUser} />;
      case 'doctor-dashboard': return <DoctorDashboard navigate={navigate} currentUser={currentUser} />;
      case 'doctor-profile': return <DoctorProfile navigate={navigate} currentUser={currentUser} />;
      case 'admin-dashboard': return <AdminDashboard />;
      case 'admin-doctors': return <AdminDoctors />;
      case 'admin-users': return <AdminUsers />;
      case 'admin-appointments': return <AdminAppointments />;
      case 'signup-doctor': return <SignupDoctorPage navigate={navigate} />;
      case 'signup-admin': return <SignupAdminPage navigate={navigate} />;
      default:
        return <HomePage />;
    }
  };

  // Admin Dashboard Component (Already implemented with charts)
  const AdminDashboard = () => (
    <div className="px-16 py-12 max-w-[1400px] mx-auto min-h-[calc(100vh-80px)] animate-fadeIn"
         style={{ background: 'var(--bg-secondary)' }}>
      <div className="rounded-[20px] px-10 py-8 mb-8 text-white flex items-center justify-between flex-wrap gap-4"
           style={{ background: 'var(--hero-gradient)' }}>
        <div>
          <h2 className="text-[28px] mb-1.5" style={{ fontFamily: "'Playfair Display', serif" }}>
            Admin Dashboard 🔑
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '15px' }}>Platform overview and analytics</p>
        </div>
        <div className="text-[64px]">📊</div>
      </div>

      <div className="grid grid-cols-4 gap-6 mb-9">
        {[
          { icon: '👨‍⚕️', number: '8', label: 'Total Doctors', sublabel: '6 available', color: 'teal' },
          { icon: '📅', number: '4', label: 'Total Appointments', sublabel: '1 pending', color: 'teal' },
          { icon: '✅', number: '1', label: 'Confirmed', sublabel: 'appointments', color: 'green' },
          { icon: '💰', number: '$94,500', label: 'Revenue', sublabel: 'this month', color: 'gold' }
        ].map((stat, i) => (
          <div key={i}
               className="rounded-2xl px-7 py-7 border transition-all duration-300 cursor-default"
               style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
               onMouseEnter={(e) => {
                 e.currentTarget.style.transform = 'translateY(-4px)';
                 e.currentTarget.style.boxShadow = 'var(--shadow-md)';
               }}
               onMouseLeave={(e) => {
                 e.currentTarget.style.transform = 'translateY(0)';
                 e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
               }}>
            <div className="text-4xl mb-4">{stat.icon}</div>
            <div className={`text-[40px] font-extrabold mb-1`}
                 style={{
                   color: stat.color === 'teal' ? 'var(--primary-teal)' :
                          stat.color === 'gold' ? 'var(--accent-gold)' : 'var(--confirmed)'
                 }}>
              {stat.number}
            </div>
            <div className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
            <div className="text-xs opacity-70" style={{ color: 'var(--text-secondary)' }}>{stat.sublabel}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-9">
        <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
             }}>
          <div className="text-lg font-bold mb-5" style={{ color: 'var(--text-primary)' }}>
            Monthly Appointments & Patients
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={monthlyAppointmentsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis dataKey="month" stroke="var(--text-secondary)" style={{ fontSize: '12px' }} />
              <YAxis stroke="var(--text-secondary)" style={{ fontSize: '12px' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'var(--text-primary)'
                }}
              />
              <Legend wrapperStyle={{ color: 'var(--text-primary)' }} />
              <Bar dataKey="appointments" fill="#0F5F5F" name="Appointments" radius={[8, 8, 0, 0]} />
              <Bar dataKey="patients" fill="#F5A623" name="Patients" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
             }}>
          <div className="text-lg font-bold mb-5" style={{ color: 'var(--text-primary)' }}>
            Appointment Status Breakdown
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={statusBreakdownData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={5}
                dataKey="value"
              >
                {statusBreakdownData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'var(--text-primary)'
                }}
              />
              <Legend wrapperStyle={{ color: 'var(--text-primary)', fontSize: '14px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
             }}>
          <div className="text-lg font-bold mb-5" style={{ color: 'var(--text-primary)' }}>
            Revenue Trend (Monthly)
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis dataKey="month" stroke="var(--text-secondary)" style={{ fontSize: '12px' }} />
              <YAxis stroke="var(--text-secondary)" style={{ fontSize: '12px' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'var(--text-primary)'
                }}
                formatter={(value: number) => `$${value.toLocaleString()}`}
              />
              <Legend wrapperStyle={{ color: 'var(--text-primary)' }} />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke="#F5A623"
                strokeWidth={3}
                dot={{ fill: '#F5A623', r: 5 }}
                name="Revenue"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl px-7 py-7 border transition-all duration-300"
             style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
             onMouseEnter={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-md)';
             }}
             onMouseLeave={(e) => {
               e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
             }}>
          <div className="text-lg font-bold mb-5" style={{ color: 'var(--text-primary)' }}>
            Doctors by Specialty
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={specialtyData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis type="number" stroke="var(--text-secondary)" style={{ fontSize: '12px' }} />
              <YAxis dataKey="specialty" type="category" stroke="var(--text-secondary)" style={{ fontSize: '12px' }} width={80} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'var(--text-primary)'
                }}
              />
              <Bar dataKey="count" fill="#0F5F5F" name="Doctors" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-2xl px-7 py-7 border overflow-x-auto transition-all duration-300"
           style={{ background: 'var(--bg-card)', borderColor: 'var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
           onMouseEnter={(e) => {
             e.currentTarget.style.boxShadow = 'var(--shadow-md)';
           }}
           onMouseLeave={(e) => {
             e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
           }}>
        <div className="text-xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Recent Appointments</div>
        <table className="w-full min-w-[600px]" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Patient</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Doctor</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Specialty</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Date</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Time</th>
              <th className="text-left px-4 py-[14px] text-xs font-bold uppercase tracking-wider border-b-2"
                  style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {[
              { patient: 'John Patient', doctor: 'Dr. Sarah Johnson', specialty: 'Cardiology', date: '2025-04-15', time: '10:00 AM', status: 'confirmed' },
              { patient: 'John Patient', doctor: 'Dr. Ahmed Hassan', specialty: 'Neurology', date: '2025-04-20', time: '2:00 PM', status: 'pending' },
              { patient: 'Sara Ali', doctor: 'Dr. Mona Khalil', specialty: 'Pediatrics', date: '2025-04-18', time: '11:00 AM', status: 'completed' },
              { patient: 'Mohamed Kareem', doctor: 'Dr. Layla Mansour', specialty: 'Dermatology', date: '2025-04-22', time: '3:00 PM', status: 'rejected' }
            ].map((appt, i) => (
              <tr key={i} className="transition-all duration-300"
                  style={{ background: 'transparent' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'var(--bg-secondary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>
                  <div className="flex items-center gap-[10px] font-semibold">👤 {appt.patient}</div>
                </td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>{appt.doctor}</td>
                <td className="px-4 py-4 text-[15px] font-semibold border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--primary-teal)' }}>{appt.specialty}</td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>{appt.date}</td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}>{appt.time}</td>
                <td className="px-4 py-4 text-[15px] border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="px-[14px] py-1 rounded-full text-xs font-semibold capitalize"
                        style={{
                          background: appt.status === 'confirmed' ? 'var(--confirmed-bg)' :
                                     appt.status === 'pending' ? 'var(--pending-bg)' :
                                     appt.status === 'completed' ? 'var(--completed-bg)' : 'var(--rejected-bg)',
                          color: appt.status === 'confirmed' ? 'var(--confirmed)' :
                                 appt.status === 'pending' ? 'var(--pending)' :
                                 appt.status === 'completed' ? 'var(--completed)' : 'var(--rejected)'
                        }}>
                    {appt.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Main render
  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      {renderNavbar()}
      {renderCurrentPage()}
    </div>
  );
}
